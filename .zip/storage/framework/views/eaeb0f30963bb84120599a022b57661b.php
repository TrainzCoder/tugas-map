<?php

use Livewire\Volt\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\{On};

?>

<div class="h-full">
    <div class="flex w-full absolute z-[1000] bottom-6 left-[50%] gap-4">
        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['wire:click' => 'startAdding']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'startAdding']); ?>Add Point <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::button.index','data' => ['wire:click' => 'clearPoints']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'clearPoints']); ?>Clear Point <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $attributes = $__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__attributesOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580)): ?>
<?php $component = $__componentOriginalc04b147acd0e65cc1a77f86fb0e81580; ?>
<?php unset($__componentOriginalc04b147acd0e65cc1a77f86fb0e81580); ?>
<?php endif; ?>
    </div>
    <div id="map" class="h-full" wire:ignore></div>
    <input id="searchBox" type="text" placeholder="Search location..." class="absolute top-8 right-[32px] transform bg-[rgba(0,0,0,.5)] backdrop-blur-xs z-[1000] w-[600px] p-2 border rounded">
    
    <script>
        document.addEventListener('livewire:init', () => {
            let map = L.map('map').setView([-6.200000, 106.816666], 15);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            }).addTo(map);

            let markers = [];
            let polygon;
            let currentPoints = [];

            const updateMarkers = (points) => {
                markers.forEach(marker => map.removeLayer(marker));
                if (polygon) map.removeLayer(polygon);

                markers = [];
                polygon = null;
                
                points.forEach(point => {
                    const marker = L.marker(point).addTo(map);
                    markers.push(marker);
                });

                if (points.length === 3) {
                    polygon = L.polygon(points, { color: 'red' }).addTo(map);
                }
            };

            updateMarkers(<?php echo e(json_encode($points)); ?>);
            currentPoints = <?php echo e(json_encode($points)); ?>;

            map.on('click', (e) => {
                if (!Livewire.getByName('addingPoints') || currentPoints.length >= 3) return;
                const { lat, lng } = e.latlng;
                Livewire.dispatch('add-point', { lat, lng });
            });

            Livewire.on('start-adding-js', () => {
                console.log('Start adding points');
                currentPoints = [];
                updateMarkers(currentPoints);
            });

            Livewire.on('point-added-js', (data) => {
                console.log('Point added', data);
                currentPoints = data.points;
                updateMarkers(currentPoints);
            });

            Livewire.on('polygon-drawn-js', (data) => {
                console.log('Polygon drawn', data);
                currentPoints = data.points;
                updateMarkers(currentPoints);
            });

            Livewire.on('points-cleared-js', () => {
                console.log('Points cleared');
                currentPoints = [];
                updateMarkers(currentPoints);
            });

            let searchBox = document.getElementById('searchBox');
            searchBox.addEventListener('keypress', function (e) {
                if (e.key === 'Enter') {
                    fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${searchBox.value}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.length > 0) {
                                let latlng = [data[0].lat, data[0].lon];
                                map.setView(latlng, 15);
                                Livewire.dispatch('add-point', { lat: latlng[0], lng: latlng[1] });
                            }
                        });
                }
            });
        });
    </script>
</div><?php /**PATH C:\laragon\www\tugas-map\resources\views\livewire/dashboard.blade.php ENDPATH**/ ?>