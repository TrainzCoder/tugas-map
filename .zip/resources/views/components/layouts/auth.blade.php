<x-layouts.auth.simple>
    {{ $slot }}
</x-layouts.auth.simple>
